#pragma once
#include "../include/hyprlang.hpp"