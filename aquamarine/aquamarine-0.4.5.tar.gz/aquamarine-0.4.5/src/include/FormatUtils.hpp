#pragma once

#include <string>
#include <cstdint>

std::string fourccToName(uint32_t drmFormat);