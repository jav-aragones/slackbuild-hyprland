#pragma once

#include "../defines.hpp"

namespace WEBP {
    cairo_surface_t* createSurfaceFromWEBP(const std::string&);
};
