#pragma once

#include "../defines.hpp"

namespace BMP {
    cairo_surface_t* createSurfaceFromBMP(const std::string&);
};