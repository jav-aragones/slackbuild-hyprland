## Usage

Include `hyprcursor/hyprcursor.h` or `.hpp` depending on your language.

Read the comments of the API functions

Have fun :)

Doxygen soon I hope :P

All props exposed are also explained in MAKING_THEMES.md

## Examples

See `tests/`.